package cn.com.pingan.cdn.repository.mysql;

/**
 * @Classname DomainVendorRepository
 * @Description TODO
 * @Date 2020/10/29 18:00
 * @Created by Luj
 */
/*
@Repository
public interface DomainVendorRepository extends JpaRepository<DomainVendor, Long>, JpaSpecificationExecutor<DomainVendor> {

    DomainVendor findByDomain(String domain);


    @Modifying
    @Transactional
    @Query(value = "select * from domain_vendor d  where d.domain in ?1", nativeQuery = true)
    List<DomainVendor> findByDomainList(List<String> domains);
}
*/
