/**   
 * @Project: anubis-content
 * @File: Command.java 
 * @Package cn.com.pingan.cdn.validator 
 * @Description: TODO() 
 * @author lujun  
 * @date 2020年9月30日 下午2:28:53 
 */
package cn.com.pingan.cdn.validator;

/** 
 * @ClassName: Command 
 * @Description: TODO() 
 * @author lujun
 * @date 2020年9月30日 下午2:28:53 
 *  
 */
public interface Command {

}
