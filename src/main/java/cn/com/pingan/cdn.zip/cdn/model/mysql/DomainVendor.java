package cn.com.pingan.cdn.model.mysql;

/**
 * @Classname DomainVendor
 * @Description TODO
 * @Date 2020/10/29 11:30
 * @Created by Luj
 */
/*
@Data
public class DomainVendor {

    @Id
    @Column(length=128)
    private String domain;

    @Column(length=128)
    private String vendors;

    private Date updateTime;
}
*/