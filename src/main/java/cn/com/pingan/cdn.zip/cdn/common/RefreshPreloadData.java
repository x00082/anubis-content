package cn.com.pingan.cdn.common;

import lombok.Data;

import java.util.List;

/**
 * @Classname RefreshPreloadData
 * @Description TODO
 * @Date 2020/10/21 19:03
 * @Created by Luj
 */
@Data
public class RefreshPreloadData {
    private List<String> urls;
}
