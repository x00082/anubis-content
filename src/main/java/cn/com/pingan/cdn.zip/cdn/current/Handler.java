package cn.com.pingan.cdn.current;

/**
 * @Classname Handler
 * @Description TODO
 * @Date 2020/10/29 20:25
 * @Created by Luj
 */
public abstract interface Handler {
}
