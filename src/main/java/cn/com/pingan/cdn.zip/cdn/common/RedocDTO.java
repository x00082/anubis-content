package cn.com.pingan.cdn.common;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Classname RedocDTO
 * @Description TODO
 * @Date 2020/11/4 17:42
 * @Created by Luj
 */
@Data
@NoArgsConstructor
public class RedocDTO {

    private String taskId;

    private Boolean force;
}
