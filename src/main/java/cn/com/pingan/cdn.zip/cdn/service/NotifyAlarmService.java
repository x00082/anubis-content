package cn.com.pingan.cdn.service;

/**
 * @Classname NotifyAlarmService
 * @Description TODO
 * @Date 2020/10/27 15:03
 * @Created by Luj
 */
public interface NotifyAlarmService {

    public int sendVendorAlarm(String msg);
}
